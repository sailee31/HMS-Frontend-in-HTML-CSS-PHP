<?php 
session_start();
 ?>

	 <main>
	 	<?php 
	 	if(isset($_SESSION["userId"])){
	 		require 'home.html';
	 	}else{
	 		require 'logoutdata.php';
	 	}	 

	 	?>
	 </main>


 <?php 
 require 'footer.php'; 
 ?>