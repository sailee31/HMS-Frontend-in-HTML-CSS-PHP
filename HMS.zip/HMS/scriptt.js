document.addEventListener("DOMContentLoaded", function () {
    const chatButton = document.getElementById("chat-button");
    const chatDialog = document.getElementById("chat-dialog");
    const closeChat = document.getElementById("close-chat");
    const messageInput = document.getElementById("message-input");
    const sendButton = document.getElementById("send-message");
    const chatContainer = document.getElementById("chat-container");

    chatButton.addEventListener("click", function () {
        chatDialog.style.display = "block";
    });

    closeChat.addEventListener("click", function () {
        chatDialog.style.display = "none";
    });

    sendButton.addEventListener("click", function () {
        const message = messageInput.value;
        if (message.trim() !== "") {
            const messageElement = document.createElement("div");
            messageElement.classList.add("user-message");
            messageElement.textContent = message;
            chatContainer.appendChild(messageElement);

            // Clear the input field
            messageInput.value = "";

            // Close the chat dialog
            chatDialog.style.display = "none";
        }
    });
});
