
<footer>
	<center><br><p>Thank You For Visiting<br>
	By HealthEase </p></center>
	<style>
		body{
			background-image: url('C:\xampp\htdocs\web_sight\12.jpg');
            background-size: cover;
            background-repeat: no-repeat;
		}
	</style>
	
</footer>